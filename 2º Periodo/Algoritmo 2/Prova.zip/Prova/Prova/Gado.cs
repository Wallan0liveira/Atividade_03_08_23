﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova
{
    public class Gado
    {
        public string raca, cor, descricao;
        public char sexo;
        public double peso, idade, codigo;

        public Gado? prox;
    }
}
